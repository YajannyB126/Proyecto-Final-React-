import "./Stories.css";

const Stories = () => {
  return (
    <>
      <div className="story">
        <img
          src="https://1.bp.blogspot.com/-JCw0pdyp_7w/VAc1kOrvoFI/AAAAAAACTXY/FvawFkSX_Gs/s1600/paisajes%2Bnaturales%2B-%2Bnaturaleza%2B-%2Bnatural%2Bfree%2Blandscapes%2B-%2Bfotos%2Bde%2Bpaisajes%2B(4).jpg"
          alt="user"
          className="story-image"
        />
        <p>Paisaje</p>
      </div>
    </>
  );
};

export default Stories;
