import './Footer.css'

const Footer=()=>{
    return(
        <>
        <div className='footer_container'>
            <div className="footer_text1">
                <p>Meta</p>
                <p>About</p>
                <p>Blog</p>
                <p>Jobs</p>
                <p>Help</p>
                <p>API</p>
                <p>Privacy</p>
                <p>Terms</p>
                <p>Locations</p>
                <p>Instagram Lite</p>
                <p>Threads</p>
                <p>Contact Uploading & Non-Users</p>
                <p>Meta Verified</p>
            </div>

            <div className="footer_text2">
                <p>English</p>
                <p>© 2023 Instagram from Meta</p>
            </div>

        </div>
        
        </>

    );
};

export default Footer;