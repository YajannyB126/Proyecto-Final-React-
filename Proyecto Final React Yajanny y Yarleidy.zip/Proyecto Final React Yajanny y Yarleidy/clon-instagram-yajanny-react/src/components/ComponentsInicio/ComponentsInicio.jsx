import "./ComponentsInicio.css";
import Publicaciones from "./Publicaciones/Publicaciones";

const ComponentsInicio = () => {
  return (
    <>
      <main>
        <Publicaciones />
      </main>

      <aside className="aside__inicio">
        <section className="aside__inicio__content">
          <section className="aside__inicio__content__img">
            <img className="aside__inicio__content__img" src="https://live.staticflickr.com/66/195608898_31048ac1b4_n.jpg" alt="" />
          </section>

          <section className="aside__inicio__content__text">
            <span>
              <b>yaja_mena04</b>
            </span>
            <span className="colorTextAside">Yajanny</span>
          </section>

          <section className="aside__inicio__content__follow">
            <span>
              <b>Switch</b>
            </span>
          </section>
        </section>

        <section className="sugerencias__content">
          <section className="sugerencias">
            <span>Suggested for you</span>
          </section>

          <section className="sugerencias__text">
            <span>
              <b>See All</b>
            </span>
          </section>
        </section>

        <section className="aside__inicio__content">
          <section className="aside__inicio__content__img">
            <img className="aside__inicio__content__img" src="https://i.pinimg.com/736x/aa/b2/ea/aab2ea306fdbbb41795b751f34ada8ab.jpg" alt="" />
          </section>

          <section className="aside__inicio__content__text">
            <span>
              <b>malu_bm09</b>
            </span>
            <span className="colorTextAside">Suggested for you</span>
          </section>

          <section className="aside__inicio__content__follow">
            <span>
              <b>Follow</b>
            </span>
          </section>
        </section>

        <section className="aside__inicio__content">
          <section className="aside__inicio__content__img">
            <img className="aside__inicio__content__img" src="https://objetivoligar.com/wp-content/uploads/2017/03/blank-profile-picture-973460_1280.jpg" alt="" />
          </section>

          <section className="aside__inicio__content__text">
            <span>
              <b>msteffa18</b>
            </span>
            <span className="colorTextAside">Suggested for you</span>
          </section>

          <section className="aside__inicio__content__follow">
            <span>
              <b>Follow</b>
            </span>
          </section>
        </section>

        <section className="aside__inicio__content">
          <section className="aside__inicio__content__img">
            <img className="aside__inicio__content__img" src="https://somoskudasai.com/wp-content/uploads/2021/05/spy-x-family.jpg" alt="" />
          </section>

          <section className="aside__inicio__content__text">
            <span>
              <b>yarleidy_m</b>
            </span>
            <span className="colorTextAside">Suggested for you</span>
          </section>

          <section className="aside__inicio__content__follow">
            <span>
              <b>Follow</b>
            </span>
          </section>
        </section>


      </aside>

    </>
  );
};

export default ComponentsInicio;
