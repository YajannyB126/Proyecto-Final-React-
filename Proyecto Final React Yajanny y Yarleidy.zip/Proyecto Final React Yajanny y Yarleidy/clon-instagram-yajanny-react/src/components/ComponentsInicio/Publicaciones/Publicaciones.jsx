import "./Publicaciones.css";

const Publicaciones = () => {
  return (
    <>
      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"30px"} width={"25px"} src="https://cdn-icons-png.flaticon.com/512/38/38351.png" alt="" /></div>
            <span>
              <b>yenes_store</b> °10h
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion6.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>3 likes</span>
          <span>
            <b>yenes_store</b>Olvida las reglas, si te gusta úsalo…
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>

      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"32px"} width={"32px"} src="https://img2.freepng.es/20181115/ify/kisspng-clip-art-shoe-portable-network-graphics-computer-i-clipart-scarpa-5bed4388a17113.2048340815422759766613.jpg" alt="" /></div>
            <span>
              <b>jm_shoesline</b> °1d
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion2.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>99 likes</span>
          <span>
            <b>jm_shoesline</b> ENTREGA INMEDIATA ✈️
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>

      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"40px"} width={"40px"} src="https://s3.amazonaws.com/imagenes.conexioncapital.co/wp-content/uploads/2022/07/19171422/LOGO-02franja-eureka.jpg" alt="" /></div>
            <span>
              <b>eureka.com1</b> °1h
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion5.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>154 likes</span>
          <span>
            <b>eureka.com1</b> Desarrollada para negocios…
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>

      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"35px"} width={"36px"} src="https://i.pinimg.com/originals/ff/7c/f4/ff7cf4718ff334a2634987d3d1a87e3a.jpg" alt="" /></div>
            <span>
              <b>almacensilue</b> °3d
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion4.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>1,500 likes</span>
          <span>
            <b>almacensilue</b> Hecha con materiales de alta calidad...
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>

      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"37px"} width={"40px"} src="https://media.istockphoto.com/vectors/shoes-logo-for-fashion-store-symbol-vector-id1175351258?k=6&m=1175351258&s=170667a&w=0&h=kth67IEvyAx6YQsUCg4GpT1uNWWW3KFODqqEWqqW4pA=" alt="" /></div>
            <span>
              <b>jm_shoesline</b> °2d
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion3.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>44 likes</span>
          <span>
            <b>jm_shoesline</b> LLEGARON...🔥
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>

      <section className="publicaciones">
        <article className="publicaciones__name">
          <div className="publicaciones__name__primero">
            <div className="publicaciones__name__primero__image"><img height={"40px"} width={"40px"} src="https://www.utch.edu.co/portal/images/logos/logo-vertica-utch.png" alt="" /></div>
            <span>
              <b>utch_edu</b> °4h
            </span>
          </div>
          <div className="publicaciones__name__segundo">
            <span>
              <b>...</b>
            </span>
          </div>
        </article>

        <article className="publicaciones__image">
          <div className="publicaciones__image__content">
            <img src="./src/imgPost/publicacion1.png" alt="" />
          </div>
        </article>

        <article className="publicaciones__icons">
          <div className="publicaciones__icons__content">
            <span>
              <img
                className="publicaciones__icons__content"
                src="https://clipground.com/images/heart-shaped-png-5.png"
                alt=""
              />
            </span>
            <span><img className="publicaciones__icons__content" src="https://www.pinclipart.com/picdir/big/571-5717511_comment-instagram-icon-png-clipart.png" alt="" /></span>
            <span><img className="publicaciones__icons__content" src="https://cdn3.iconfinder.com/data/icons/basic-user-interface-application/32/INSTAGRAM_ICON_SETS-05-512.png" alt="" /></span>
          </div>

          <div className="publicaciones__icons__content">
            <span><img className="publicaciones__icons__content" src="https://cdn1.iconfinder.com/data/icons/instagram-feature-outline/32/icon_instagram-27-512.png" alt="" /></span>
          </div>
        </article>

        <article className="publicaciones__text">
          <span>450 likes</span>
          <span>
            <b>utch_edu</b> 📸 #SemanaEnImágenes
          </span>
          <span className="colorComment">Add comment...</span>
          <div className="linea_inicio"></div>
        </article>
      </section>
    </>
  );
};

export default Publicaciones;
