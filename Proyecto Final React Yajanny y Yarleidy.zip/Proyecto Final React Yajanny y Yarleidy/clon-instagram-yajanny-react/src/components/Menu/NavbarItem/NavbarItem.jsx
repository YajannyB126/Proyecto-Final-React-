import "./NavbarItem.css";
import { Outlet, NavLink } from "react-router-dom";

const NavbarItem = ({ icon, action,onNavLink=true, toProp }) => {
  return (
    <>
      <div className="item-principal">
        <div className="item-icon">
          {" "}
          <img src={icon} alt="" />{" "}
        </div>
        <div className="item-text"> 
        {onNavLink ? (<span>{action}</span>) : (<NavLink to={toProp}>{action}</NavLink>)}

        </div>
      </div>
    </>
  );
};

export default NavbarItem;
