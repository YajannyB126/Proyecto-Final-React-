import "../Menu/Menu.css";
import Navbar from "./Navbar/Navbar";
import NavbarItem from "./NavbarItem/NavbarItem";
import ToggleMenu from "./ToggleMenu/ToggleMenu";

const Header = () => {
  return (
    <header className="header">
      <Navbar />
      <NavbarItem />
      <ToggleMenu />
    </header>
  );
};

export default Header;
