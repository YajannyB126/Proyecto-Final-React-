import "./ComponentsProfile.css";
import Profile from "./Profile/Profile";
import Post from "./Post/Post";
import Footer from "../Footer/Footer";

const ComponentsProfile = () => {
  return (
    <main className="main">
      <Profile />
      <Post />
      <Footer />
    </main>
  );
};

export default ComponentsProfile;
