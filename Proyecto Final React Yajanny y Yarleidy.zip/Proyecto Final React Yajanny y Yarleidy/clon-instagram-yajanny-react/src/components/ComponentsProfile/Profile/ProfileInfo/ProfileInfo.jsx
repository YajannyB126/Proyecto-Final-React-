import './ProfileInfo.css'


const ProfileInfo = ()=>{
    return(
        <>
        <div className='profile_info'>
            <p><b>Yajanny</b></p>
            <p>Quibdó - Chocó 🇬🇦</p>

        </div>
     
        </>
    )
};

export default ProfileInfo;