import './ProfileUp.css'

const ProfileUp = ()=>{
    return(
        <>
        <div className='ProfileUpItem'>
            <p>yaja_mena04</p>

        </div>
        <div className='ProfileUpItem'>

            <div></div>
            <div></div>

        </div>
        
        </>
    )
};

export default ProfileUp