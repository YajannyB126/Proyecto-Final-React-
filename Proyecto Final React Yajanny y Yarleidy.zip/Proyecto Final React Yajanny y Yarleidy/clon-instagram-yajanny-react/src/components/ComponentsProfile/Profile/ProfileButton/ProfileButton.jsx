import './ProfileButton.css'

const ProfileButton =()=>{
    return(
        <>
        <div className='Profile_Button'>
            <button >Editar perfil</button>
            <button>Compartir perfil</button>
        </div>
        
        </>
    );
};

export default ProfileButton;