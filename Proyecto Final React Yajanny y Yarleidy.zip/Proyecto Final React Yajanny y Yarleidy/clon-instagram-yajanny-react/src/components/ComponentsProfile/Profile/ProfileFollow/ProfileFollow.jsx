import "./ProfileFollow.css";


const ProfileFollow = () => {
  return (
    <>
      <div className="ProfileFollow_main_container">
        <div className="ProfileFollow_item">
          <div></div>
        </div>

        <div className="ProfileFollow_item">
            
          <div className="ProfileFollow_item">
            <p><b>12</b></p>
            <p>Publicaciones</p>
          </div>

          <div className="ProfileFollow_item">
          <p><b>21</b></p>
          <p>Seguidores</p>
        </div>
        <div className="ProfileFollow_item">
          <p><b>103</b></p>
          <p>Seguidos</p>
        </div>

        </div>



      </div>
    </>
  );
};

export default ProfileFollow;
