import './Profile.css'

import ProfileButton from './ProfileButton/ProfileButton';
import ProfileFollow from './ProfileFollow/ProfileFollow';
import ProfileInfo from './ProfileInfo/ProfileInfo';
// import ProfileUp from './ProfileUp/ProfileUp';
import Stories from "../../Stories/Stories"


const Profile =  () =>{

    return(
        <>
        <div className='Profile_content'>
            
            <ProfileFollow/>
            <ProfileButton/>
            <ProfileInfo/>
            {/* <ProfileUp/> */}
            <Stories/>

        </div>
        </>
    )
};

export default Profile;