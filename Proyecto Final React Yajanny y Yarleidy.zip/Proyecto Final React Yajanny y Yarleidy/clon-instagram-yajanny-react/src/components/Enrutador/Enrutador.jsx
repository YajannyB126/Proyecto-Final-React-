import { useRoutes, BrowserRouter } from "react-router-dom";
import ComponentsInicio from "../ComponentsInicio/ComponentsInicio";
import ComponentsProfile from "../ComponentsProfile/ComponentsProfile";

const AppRoutes=()=>{
    const routes = useRoutes([
        {
            path:"/",
            element: <ComponentsInicio/>
        },
        {
            path:"/profile",
            element: <ComponentsProfile/>
        }



    ])
    
    return routes;
};

const RoutesWrapper = ({children}) => {
    return (
      <BrowserRouter> {/* Usamos BrowserRouter para gestionar las rutas */}
        {children} {/* Pasamos los componentes hijos como prop */}
        <AppRoutes /> {/* Renderizamos las rutas configuradas */}
      </BrowserRouter>
    );
  };
  
  // Exportamos el componente RoutesWrapper
  export default RoutesWrapper;
