// import reactLogo from './assets/react.svg'
import viteLogo from "/vite.svg";
import "./App.css";
import Menu from "./components/Menu/Menu";
import ProfileUp from "./components/ComponentsProfile/Profile/ProfileUp/ProfileUp";
import ComponentsProfile from "./components/ComponentsProfile/ComponentsProfile";
import RoutesWrapper from "./components/Enrutador/Enrutador";
function App() {
  return (
    <>
      <RoutesWrapper>
        {/* Renderizamos el componente de navegación 'Nav' */}
        <Menu />
      </RoutesWrapper>
    

      <aside className="aside">
        <ProfileUp />
      </aside>
    </>
  );
}

export default App;
